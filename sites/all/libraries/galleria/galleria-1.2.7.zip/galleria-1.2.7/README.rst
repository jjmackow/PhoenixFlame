********
Galleria
********
**A JavaScript image gallery for the fastidious.**

Info & demos: http://galleria.io

Updates via twitter: http://twitter.com/galleriajs

Documentation
=============

Documentation is currently available in `reST
<http://en.wikipedia.org/wiki/ReStructuredText>`_ format in the repository.

You can build local HTML using Sphinx: http://sphinx.pocoo.org/.