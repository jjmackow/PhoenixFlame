==================
imagePanSmoothness
==================

    | type: **Number**
    | default: **12**

This value sets how "smooth" the image pan movement should be when setting image_pan to true.
The higher value, the smoother effect but also CPU consuming.