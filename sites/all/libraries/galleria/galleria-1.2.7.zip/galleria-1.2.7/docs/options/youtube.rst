=======
youtube
=======

    | type: **Object**
    | default: **(see below)**

You can customize the YouTube player using the YouTube Player parameters.
By default, Galleria sets the player to look minimal and strips out some UI elements, but this options lets you customize as you wish.

List of all available parameters: http://code.google.com/apis/youtube/player_parameters.html

Default youtube options::

    {
        modestbranding: 1,
        autohide: 1,
        color: 'white',
        hd: 1,
        rel: 0,
        showinfo: 0
    }