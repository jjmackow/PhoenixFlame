===============
touchTransition
===============

    | type: **String**
    | default: **undefined**

Defines a different transition when a touch device is detected. See the transition option for info about the different transitions.