=========
idleSpeed
=========

    | type: **Number**
    | default: **200**

If you are adding elements into idle mode using the ``addIdleState()`` method,
you can control the animation speed of the idle elements.

idleSpeed is set using milliseconds.