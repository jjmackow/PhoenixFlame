=================
lightboxFadeSpeed
=================

    | type: **Number**
    | default: **200**

When calling ``.showLightbox()`` the lightbox will animate and fade the images and captions.
This value controls how fast they should fade in milliseconds.