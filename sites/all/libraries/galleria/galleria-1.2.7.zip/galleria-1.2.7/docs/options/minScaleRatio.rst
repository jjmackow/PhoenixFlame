=============
minScaleRatio
=============

    | type: **Number**
    | default: **undefined**

Sets the minimum scale ratio for images.
F.ex, if you don't want Galleria to downscale any images, set this to 1.

undefined will allow any scaling of the images.