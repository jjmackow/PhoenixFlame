===================
fullscreenDoubleTap
===================

    | type: **Boolean**
    | default: **true**

This options listens for the double-tap event on touch devices and toggle fullscreen mode if it happens.