==============
trueFullscreen
==============

    | type: **Boolean**
    | default: **true**

Galleria supports true fullscreen mode if it is supported by the browser (currently FF10+, Safari 5.1+ and Chrome 15+).
That means that it will enter a native OS fullscreen if the fullscreen method is triggered.

If you don’t want this behavior, set this option to false.