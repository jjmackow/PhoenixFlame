========
carousel
========

    | type: **Boolean**
    | default: **true**

Galleria comes with a built-in horizontal carousel. This options is for activating / deactivating the carousel feature.
Setting this to ``true``, the carousel will be automatically applied if the total som of thumbnails width exceeds the thumbnail container.
This will be re-calculaed on resize.

If you set this to ``false``, you will prevent Galleria from adding the carousel.