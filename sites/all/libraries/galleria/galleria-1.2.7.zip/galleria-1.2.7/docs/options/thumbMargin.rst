===========
thumbMargin
===========


    | type: **Number**
    | default: **0**

Same as **imageMargin** but for thumbnails.