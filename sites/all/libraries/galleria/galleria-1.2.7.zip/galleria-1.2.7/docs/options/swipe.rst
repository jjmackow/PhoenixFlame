=====
swipe
=====

    | type: **Boolean**
    | default: **true**

Enables a swipe movement for flicking through images on touch devices.