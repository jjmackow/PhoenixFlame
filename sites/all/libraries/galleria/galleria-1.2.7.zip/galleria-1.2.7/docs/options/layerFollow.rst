===========
layerFollow
===========

    | type: **Boolean**
    | default: **true**

By default, the layer follows the image size on the stage, even if crop is set. This means that the HTML layer will stretch according to the active image.
If you want the layer to fill the stage regardless of cropping settings, set this to false.