============
imageTimeout
============

    | type: **Number**
    | default: **30000**

This option defines how long Galleria will try to fetch the images (unless it returns 404) before an exception is thrown.
It uses milliseconds, so 30000 is 30 sec.