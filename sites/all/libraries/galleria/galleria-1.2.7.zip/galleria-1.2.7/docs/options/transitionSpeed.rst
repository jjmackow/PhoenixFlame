===============
transitionSpeed
===============

    | type: **Number**
    | default: 400

The milliseconds used in the animation when applying the transition.
The higher number, the slower transition.