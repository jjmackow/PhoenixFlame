========
thumbFit
========

    | type: **Boolean**
    | default: **true**

If this is set to 'true', all thumbnail containers will be shrinked to fit the actual thumbnail size.
This is useful if you have thumbnails of various sizes and will then float nicely side-by-side.

This is only relevant if thumbCrop is set to anything else but 'true'.
If you want all thumbnails to fit inside a container with predefined width & height, set this to 'false'.