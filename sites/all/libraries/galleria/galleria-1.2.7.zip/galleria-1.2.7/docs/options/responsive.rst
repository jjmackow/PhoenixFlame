==========
responsive
==========

    | type: **Boolean**
    | default: **false**

This option sets thew Gallery in responsive mode. That means that it will resize the entire container if your CSS is dynamic.
In other words, you can add media queries or dynamic proportions in your CSS and the gallery will follow these proportions as the window resizes.