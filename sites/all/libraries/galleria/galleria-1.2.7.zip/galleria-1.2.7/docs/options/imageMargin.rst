===========
imageMargin
===========

    | type: **Number**
    | default: **0**

Since images are scaled to fit the stage container, there might be occations when you need to
apply a margin between the image and stage border. This is what this option is for.

The margin is set in pixels.