==============
carouselFollow
==============

    | type: **Boolean**
    | default: **true**

This option defines if the the carousel should follow the active image.
You can control the speed of the animation with the :doc:`carouselSpeed` option.
Please note that animating heavy thumbnails can affect your main image animation,
so if you are seeing big lags in the main animation you can try to set this option to ``false``.