=========
idleMode
=========

    | type: **Boolean**
    | default: **true**

Global option for turning on/off idle mode. 
Eache gallery enters idle mode after certain amount of time and themes behave differently when this happens, f.ex clears the stage from distractions.
If you want to prevent idle mode from ever occuring, set this to false.