=======================
lightboxTransitionSpeed
=======================

    | type: **Number**
    | default: **300**

When calling ``.showLightbox()`` the lightbox will animate the white square before displaying the image.
This value controls how fast it should animate in milliseconds.