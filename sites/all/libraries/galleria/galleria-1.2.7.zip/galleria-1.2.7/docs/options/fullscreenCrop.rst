==============
fullscreenCrop
==============

    | type: **Boolean**
    | default: **undefined**

Sets how Galleria should crop when in fullscreen mode. See imageCrop for cropping options.