==============
overlayOpacity
==============

    | type: **Number**
    | default: **0.85**

This sets how much opacity the overlay should have when calling ``showLightbox()``