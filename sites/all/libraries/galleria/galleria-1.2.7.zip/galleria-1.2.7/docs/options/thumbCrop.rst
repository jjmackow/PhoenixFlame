=========
thumbCrop
=========

    | type: **Boolean** or **String**
    | default: **true**

Same as **imageCrop** but for thumbnails.