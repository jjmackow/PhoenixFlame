======
easing
======

    | type: **String**
    | default: *galleria*

You can use this option to control the animation easing on a global level in Galleria.

Besides the built-in jQuery easings "linear" and "swing", Galleria includes the following easings:

- **galleria**
- **galleriaIn**
- **galleriaOut**

You can use any of these easings or any other easing plugin, f.ex the jQuery Easing Plugin.