====
show
====

    | type: **Number**
    | default: **0**

This defines what image index to show at first.
If you use the history plugin, a permalink will override this number.