====================
fullscreenTransition
====================

    | type: **String**
    | default: **undefined**

Defines a different transition for fullscreen mode.
Some transitions are less smooth in fullscreen mode, this option allows you to set a different transition when in fullscreen mode. See the transition option for info about the different transitions.