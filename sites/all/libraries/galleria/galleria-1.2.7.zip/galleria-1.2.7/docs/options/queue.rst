=====
queue
=====

    | type: **Boolean**
    | default: **true**

Galleria queues all activation clicks (next/prev & thumbnails).
You can see this effect when f.ex clicking "next" fast many times.

If you don't want Galleria to queue, set this to **false**.
This will make Galleria stall during animations.