.. highlight:: javascript

*******
Classic
*******

The free open sourced theme that comes bundled with the Galleria core.

Defaults
--------

::

    {
        transition: "slide",
        thumbCrop: "height"
    }

Theme-specific options
----------------------

::

    {
        // Set this to false if you want the caption to show always
        _toggleInfo: true
    }